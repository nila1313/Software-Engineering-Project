package employee;
import java.util.ArrayList;

import javax.swing.table.AbstractTableModel;

import SS.DataAccess;
import items.items;

public class employeeTableModel extends AbstractTableModel {

	private String[] colNames = {"id","name","password","designation"};
	ArrayList<EmployeeCreate> EmployeeList=new ArrayList<EmployeeCreate>(); 
	DataAccess da=new DataAccess();
	
	public employeeTableModel() {
		DataAccess da = new DataAccess();
		EmployeeList = da.AllEmployee();
	}
		
	public void fixEmployee(ArrayList<EmployeeCreate> EmployeeList) {
		this.EmployeeList=EmployeeList;
	}
	
	
	public int getColumnCount() {
		return colNames.length;
	}

	public int getRowCount() {
		return EmployeeList.size();
	}
	
	public String getColumnName(int col) {
		return colNames[col];
	}

	public Object getValueAt(int row, int col) {
		if(EmployeeList.size()==0)
			return null;
		
		try
		{
			EmployeeCreate e = EmployeeList.get(row);
			switch(col)
			{
				case 0:
					return e.id;
				case 1:
					return e.name;
				case 2:
					return e.password;
				case 3:
					return e.designation;
				default:
					return null;
			}
			
		}
		catch(Exception ex)
		{
			return null;
		}
	}
}
