package manager;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.*;

import SS.DataAccess;
import SS.Salesman;
import items.ItemTableModel;
import items.items;

public class ItemGUI extends JFrame {
	private JPanel inLayer;
	private DataAccess da=new DataAccess();
	private JTable itemTable;
	private JScrollPane sp;
	private JButton addItem, deleteItem, searchItem,updateItem,confirmUpdate,refreshBtn;;
	private JTextField nameBox;
	private JTextField categoryBox;
	private JTextField priceBox;
	private JTextField quantityBox;
	private JLabel search;
	private JLabel name;
	private JLabel category;
	private JLabel price;
	private JLabel quantity;
	private JTextField searchTextField;
	ItemTableModel model;
	
	private JLabel background;
	
	int selectedRow=-1;//FOR COMMUNICATION BETWEEN 'UPDATE' AND 'UPDATE CONFIRM'
	ItemGUI(){
		setBounds(20,20,800,600);
		setTitle("Items");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLayout(null);
		
		inLayer=new JPanel();
		inLayer.setBounds(0,0,800,600);
		inLayer.setLayout(null);
		add(inLayer);
		
		initComponent();
	}
	private void initComponent(){
		addItem= new JButton("Add");
		addItem.setBounds(40,50,80,30);
		addItem.setBackground(Color.ORANGE);
		addItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					float quantity=Float.parseFloat(quantityBox.getText());
					float price=Float.parseFloat(priceBox.getText());
					da.addItem(nameBox.getText(), categoryBox.getText(), price, quantity);
					populateTable();
				}
				catch(Exception ee) {
					JOptionPane.showMessageDialog(null, "Insert Valid input");
				}
			}
		});
		inLayer.add(addItem);
		
		
		deleteItem= new JButton("Delete");
		deleteItem.setBounds(140,50,80,30);
		deleteItem.setBackground(Color.ORANGE);
		deleteItem.setCursor(new Cursor(Cursor.HAND_CURSOR));
		deleteItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int itemId=(int)itemTable.getModel().getValueAt(itemTable.getSelectedRow(),0);
					da.removeItem(itemId);
					populateTable();
				}
				catch(Exception ee) {
					JOptionPane.showMessageDialog(null,"Select a Row");
				}
			}
		});
		inLayer.add(deleteItem);
		
		searchItem= new JButton("Search");
		searchItem.setBounds(240,50,80,30);
		searchItem.setBackground(Color.ORANGE);
		searchItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				items it=da.getItem(searchTextField.getText());
				if(it!=null) {
					ArrayList<items> itemSend=new ArrayList<items>();
					itemSend.add(it);
					model=new ItemTableModel();
					model.fixItem(itemSend);
					itemTable.setModel(model);
				}
			}
		});
		inLayer.add(searchItem);
		
		updateItem= new JButton("Update");
		updateItem.setBounds(340,50,80,30);
		updateItem.setBackground(Color.ORANGE);
		updateItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					selectedRow=(int)itemTable.getModel().getValueAt(itemTable.getSelectedRow(), 0);
					nameBox.setText((String) itemTable.getModel().getValueAt(itemTable.getSelectedRow(), 1));
					categoryBox.setText((String) itemTable.getModel().getValueAt(itemTable.getSelectedRow(), 2));
					priceBox.setText("" + (float) itemTable.getModel().getValueAt(itemTable.getSelectedRow(), 3));
					quantityBox.setText("" + (float) itemTable.getModel().getValueAt(itemTable.getSelectedRow(), 4));
					confirmUpdate.setVisible(true);
				} catch (Exception e2) {
					JOptionPane.showMessageDialog(null,"Select a row please!");
				}
			}
		});
		inLayer.add(updateItem);
		
		
		
	
		this.tableToScroll();
		
		name=new JLabel("Name");
		name.setBounds(500,100,60,30);
		name.setForeground(Color.RED);
		name.setBackground(Color.WHITE);
		name.setOpaque(true);
		name.setFont(new Font(Font.SERIF,Font.BOLD,18));
		inLayer.add(name);
		
		nameBox=new JTextField();
		nameBox.setBounds(590,100,100,30);
		inLayer.add(nameBox);
		
		category=new JLabel("Category");
		category.setBounds(500,140,80,30);
		category.setForeground(Color.RED);
		category.setBackground(Color.WHITE);
		category.setOpaque(true);
		category.setFont(new Font(Font.SERIF,Font.BOLD,18));
		inLayer.add(category);
		
		categoryBox=new JTextField();
		categoryBox.setBounds(590,140,100,30);
		inLayer.add(categoryBox);
		
		price=new JLabel("Price");
		price.setBounds(500,180,60,30);
		price.setForeground(Color.RED);
		price.setBackground(Color.WHITE);
		price.setOpaque(true);
		price.setFont(new Font(Font.SERIF,Font.BOLD,18));
		inLayer.add(price);
		
		priceBox=new JTextField();
		priceBox.setBounds(590,180,100,30);
		inLayer.add(priceBox);
		
		quantity=new JLabel("Quantity");
		quantity.setBounds(500,220,80,30);
		quantity.setForeground(Color.RED);
		quantity.setBackground(Color.WHITE);
		quantity.setOpaque(true);
		quantity.setFont(new Font(Font.SERIF,Font.BOLD,18));
		inLayer.add(quantity);
		
		quantityBox=new JTextField();
		quantityBox.setBounds(590,220,100,30);
		inLayer.add(quantityBox);	
		

		search=new JLabel("Search");
		search.setBounds(500,260,80,30);
		search.setForeground(Color.RED);
		search.setBackground(Color.WHITE);
		search.setOpaque(true);
		search.setFont(new Font(Font.SERIF,Font.BOLD,18));
		inLayer.add(search);
		

		searchTextField = new JTextField();
		searchTextField.setBounds(590,260,100,30);
		inLayer.add(searchTextField);		
		
		confirmUpdate=new JButton("Confirm");
		confirmUpdate.setBounds(560,310,100,30);
		confirmUpdate.setVisible(false);
		confirmUpdate.setBackground(Color.RED);
		confirmUpdate.setFont(new Font(Font.SERIF,Font.BOLD,18));
		confirmUpdate.setForeground(Color.WHITE);
		confirmUpdate.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				da.updateItem(selectedRow,nameBox.getText(),categoryBox.getText(),priceBox.getText(),quantityBox.getText());
				nameBox.setText("");
				categoryBox.setText("");
				priceBox.setText("");
				quantityBox.setText("");
				populateTable();
				confirmUpdate.setVisible(false);			
			}
		});
		inLayer.add(confirmUpdate);
		
		refreshBtn=new JButton("Refresh");
		refreshBtn.setBounds(560,360,100,30);
		refreshBtn.setBackground(Color.RED);
		refreshBtn.setFont(new Font(Font.SERIF,Font.BOLD,18));
		refreshBtn.setForeground(Color.WHITE);
		refreshBtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				populateTable();
				
			}
		});
		inLayer.add(refreshBtn);
		
	//SET BACKGROUND
		background=new JLabel(new ImageIcon("C:\\Users\\chmaitra\\Desktop\\NilaSS\\SS\\src\\image\\IT.jpg"));
	    background.setBounds(0,0,800,600);	
		inLayer.add(background);
	}
	
	
	
	//Adding table to ScrollPane
	public void tableToScroll() {
		model =new ItemTableModel();
		model.allItems();
		itemTable=new JTable(model);
		sp=new JScrollPane();
		sp.setBounds(40,100,400,400);
		itemTable.setBackground(Color.ORANGE);
		inLayer.add(sp);
		sp.setViewportView(itemTable);
		this.populateTable();
		
	}
	
	public void populateTable() {
		model =new ItemTableModel();
		model.allItems();
		itemTable.setModel(model);
	}

}

