package manager;
import javax.swing.*;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.util.ArrayList;

import SS.DataAccess;
import employee.EmployeeCreate;
import employee.employeeTableModel;
import items.ItemTableModel;
import items.items;

public class EmployeeGUI extends JFrame {

	JPanel inLayer;
	ArrayList<EmployeeCreate> EmployeeList=new ArrayList<EmployeeCreate>(); //Cart
	DataAccess da=new DataAccess();
	ResultSet result;
	JTable employeeTable;
	JScrollPane sp;
	JButton addEmployee, deleteEmployee, searchEmployee,updateEmployee,confirmUpdate;
	private JTextField searchBox, newName, newDesignation;
	private JLabel searchItem, empName, empPassword,empDesignation;
	private JPasswordField newPassword;
	private JLabel background;
	
	int selectedRow=-1;//FOR COMMUNICATION BETWEEN 'UPDATE' AND 'UPDATE CONFIRM'
	public EmployeeGUI(){
		setBounds(20,20,800,600);
		setTitle("Employee List");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLayout(null);

		inLayer=new JPanel();
		inLayer.setBounds(0,0,800,600);
		inLayer.setLayout(null);
		add(inLayer);	
		
		initComponents();
	}
	public void initComponents() {
		searchBox= new JTextField();
		searchBox.setBounds(600,130,80,30);
		inLayer.add(searchBox);
		
		newName= new JTextField();
		newName.setBounds(600,170,80,30);
		inLayer.add(newName);
		
		newPassword= new JPasswordField();
		newPassword.setBounds(600,210,80,30);
		inLayer.add(newPassword);
		
		newDesignation= new JTextField();
		newDesignation.setBounds(600,250,80,30);
		inLayer.add(newDesignation);
		
		searchItem= new JLabel("Search");
		searchItem.setBounds(500,130,80,30);
		searchItem.setForeground(Color.WHITE);
		searchItem.setBackground(Color.BLACK);
		searchItem.setOpaque(true);
		searchItem.setFont(new Font(Font.SERIF,Font.BOLD,18));
		inLayer.add(searchItem);
		
		empName= new JLabel("Name");
		empName.setBounds(500,170,80,20);
		empName.setForeground(Color.WHITE);
		empName.setBackground(Color.BLACK);
		empName.setOpaque(true);
		empName.setFont(new Font(Font.SERIF,Font.BOLD,18));
	
		inLayer.add(empName);
		
		empPassword= new JLabel("Password");
		empPassword.setBounds(500,210,80,20);
		empPassword.setForeground(Color.WHITE);
		empPassword.setBackground(Color.BLACK);
		empPassword.setOpaque(true);
		empPassword.setFont(new Font(Font.SERIF,Font.BOLD,18));
		
		inLayer.add(empPassword);
		
		empDesignation= new JLabel("Designation");
		empDesignation.setBounds(500,250,100,30);
		empDesignation.setForeground(Color.WHITE);
		empDesignation.setBackground(Color.BLACK);
		empDesignation.setOpaque(true);
		empDesignation.setFont(new Font(Font.SERIF,Font.BOLD,18));
		
		inLayer.add(empDesignation);
		
		addEmployee= new JButton("ADD");
		addEmployee.setBounds(40,40,100,30);
		addEmployee.setForeground(Color.WHITE);
		addEmployee.setBackground(Color.BLACK);
		addEmployee.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if (!newName.getText().equals("")) {
						da.addEmployee(newName.getText(), newPassword.getText(), newDesignation.getText());
						populateTable();
					}
				}
				catch(Exception ee) {
					JOptionPane.showMessageDialog(null, "Insert Valid input");
				}
			}
		});
		
		inLayer.add(addEmployee);
		
       
		deleteEmployee= new JButton("DELETE");
		deleteEmployee.setBounds(140,40,100,30);
		deleteEmployee.setForeground(Color.WHITE);
		deleteEmployee.setBackground(Color.GRAY);
		deleteEmployee.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int employeeId=(int)employeeTable.getModel().getValueAt(employeeTable.getSelectedRow(),0);
					da.removeEmployee(employeeId);
					populateTable();
				}
				catch(Exception ee) {
					JOptionPane.showMessageDialog(null,"Select a Row");
				}
				
			}
		});
		inLayer.add(deleteEmployee);
		
		searchEmployee= new JButton("SEARCH");
		searchEmployee.setBounds(240,40,100,30);
		searchEmployee.setForeground(Color.WHITE);
		searchEmployee.setBackground(Color.BLACK);
		searchEmployee.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EmployeeCreate em=da.getEmployee(searchBox.getText());
				if(em!=null) {
					ArrayList<EmployeeCreate> employeeSend=new ArrayList<EmployeeCreate>();
					employeeSend.add(em);
					employeeTableModel model = new employeeTableModel();
					model.fixEmployee(employeeSend);
					employeeTable.setModel(model);
				}
			}
		});
		inLayer.add(searchEmployee);
		
		updateEmployee=new JButton("UPDATE");
		updateEmployee.setBounds(340,40,100,30);
		updateEmployee.setForeground(Color.WHITE);
		updateEmployee.setBackground(Color.GRAY);
		updateEmployee.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					selectedRow=(int)employeeTable.getModel().getValueAt(employeeTable.getSelectedRow(), 0);
					newName.setText((String) employeeTable.getModel().getValueAt(employeeTable.getSelectedRow(), 1));
					newPassword.setText((String) employeeTable.getModel().getValueAt(employeeTable.getSelectedRow(), 2));
					newDesignation.setText((String)employeeTable.getModel().getValueAt(employeeTable.getSelectedRow(), 3));
					confirmUpdate.setVisible(true);
				} catch (Exception e2) {
					JOptionPane.showMessageDialog(null,"Select a row please!");
				}
			}
		});
		inLayer.add(updateEmployee);
		
		confirmUpdate=new JButton("CONFIRM");
		confirmUpdate.setBounds(560,350,100,30);
		confirmUpdate.setForeground(Color.WHITE);
		confirmUpdate.setBackground(Color.RED);
		confirmUpdate.setVisible(false);
		confirmUpdate.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				da.updateEmployee(selectedRow,newName.getText(),newPassword.getText(),newDesignation.getText());
				newName.setText("");
				newPassword.setText("");
				newDesignation.setText("");
				populateTable();
				confirmUpdate.setVisible(false);
				
			}
		});
		inLayer.add(confirmUpdate);
		
		this.tableToScroll();

		//SET BACKGROUND
		background=new JLabel(new ImageIcon("C:\\Users\\chmaitra\\Desktop\\NilaSS\\SS\\src\\image\\EI.jpg"));
	    background.setBounds(0,0,800,600);	
		inLayer.add(background);
		
		
	
		
	}
	
	
	//Adding table to ScrollPane
	public void tableToScroll() {
		employeeTable=new JTable();
		employeeTable.setBackground(Color.LIGHT_GRAY);
		sp=new JScrollPane();
		sp.setBounds(40,100,400,400);
		inLayer.add(sp);
		sp.setViewportView(employeeTable);
		this.populateTable();
		
	}
	
	public void populateTable() {
		employeeTableModel model =new employeeTableModel();
		employeeTable.setModel(model);
	}

}
	