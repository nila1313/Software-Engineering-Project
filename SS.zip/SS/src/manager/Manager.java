package manager;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import SS.DataAccess;
import SS.Login;
import employee.EmployeeCreate;

public class Manager extends JFrame {
	DataAccess da=new DataAccess();
	
	private Login login;
	
	Manager man=this;
	EmployeeCreate employee;
	JPanel panel1;
	JLabel showName;
	JLabel background;
	
	JButton btnlogout;
	JButton btnEmployees;
	JButton btnItems;
	public Manager(Login login,EmployeeCreate employee) {
		
		//Variables
		this.login=login;
		this.employee=employee;
		
		//Frame
		setTitle("Manager");
		setBounds(400,150,640,400);
		setLayout(null);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		//Panel
		panel1=new JPanel();
		panel1.setBounds(0,0,640,400);
		panel1.setLayout(null);
		add(panel1);
		
		
		
		initComponents();
	}
	
	private void initComponents() {
		//Show Name
		showName=new JLabel();
		showName.setBounds(330, 60, 250, 40);
		showName.setBackground(Color.WHITE);
		showName.setFont(new Font("Lucida Handwriting",Font.BOLD,22));
		showName.setForeground(Color.red);
		showName.setOpaque(true);
		showName.setText("Hi, "+employee.getName());
		panel1.add(showName);
	
		//LOGOUT
		btnlogout=new JButton();
		btnlogout.setBounds(580,10,40,40);
		btnlogout.setBackground(Color.WHITE);
		btnlogout.setIcon(new ImageIcon("C:\\Users\\chmaitra\\Desktop\\SS\\src\\image\\LO.png"));
		btnlogout.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				man.dispose();
				login.setVisible(true);
				
			}
		});
		panel1.add(btnlogout);
		
		
		//EMPLOYEE
		btnEmployees =new JButton("Employees");
		btnEmployees.setFont(new Font("Lucida Handwriting",Font.BOLD,15));
		btnEmployees.setBounds(400, 140, 140, 30);
		btnEmployees.setBackground(Color.red);
		btnEmployees.setForeground(Color.WHITE);
		btnEmployees.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent arg0) {
				EmployeeGUI employeList=new EmployeeGUI();
				employeList.setVisible(true);
				
			}
		});
		panel1.add(btnEmployees);
		
		//ITEMS
		btnItems = new JButton("Items");
		btnItems.setBounds(400, 210, 140, 30);
		btnItems.setBackground(Color.red);
		btnItems.setFont(new Font("Lucida Handwriting",Font.BOLD,15));
		btnItems.setForeground(Color.WHITE);
		btnItems.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ItemGUI itg=new ItemGUI();
				itg.setVisible(true);
			}
		});
		panel1.add(btnItems);
		
		
		background=new JLabel(new ImageIcon("C:\\Users\\chmaitra\\Desktop\\SS\\src\\image\\MG.jpg"));
		background.setBounds(0,0,640,400);	
		panel1.add(background);
				
	}
 
}
