package SS;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

import employee.EmployeeCreate;
import items.items;

public class DataAccess {
	Connection con;
	Statement state;
	ResultSet result;
	public DataAccess() {
		
		try {
			con= (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/java","root","");
			state=(Statement) con.createStatement();		
		}
		catch(Exception e) {
			JOptionPane.showMessageDialog(null, "Cannot Connect");
		}
	}
	
	
	//Adding Item
	public void addItem(String name,String category,float price,float quantity) {
		String sql="insert into items VALUES( null, '"+name+"', '"+category+"', "+price+","+quantity+")";
		try {
			state.executeUpdate(sql);
		}
		catch(Exception e) {
			JOptionPane.showMessageDialog(null,"Wrong Id");
		}
	}
	
	//UPDATING ITEM
	public void updateItem(int id, String name, String category, String price, String quantity) {
		String sql="update items set name='"+name+"',category='"+category+"',price="+price+",quantity="+quantity+" where id="+id;
		try {
			state.executeUpdate(sql);
		}
		catch(Exception e) {
			JOptionPane.showMessageDialog(null,"Enter Valid Input");
		}
		
	}	
		
	
	//Deleting Item
	public void removeItem(int id) {
		String sql="delete from items where id="+id;
		try {
			state.executeUpdate(sql);
		}
		catch(Exception e) {
			JOptionPane.showMessageDialog(null,"Wrong Id");
		}
	}
	
	//Fetching Individual Item with Name
	public items getItem(String itemName) {
		String sql="select * from items where name like '"+itemName+"%'";
		items it = new items();
		try {
			result=state.executeQuery(sql);
			result.next();
			it.setId(result.getInt("id"));
			it.setName(result.getString("name"));
			it.setCategory(result.getString("category"));
			it.setPrice(result.getFloat("price"));
			it.setQunatity(result.getFloat("quantity"));
			return it;
		}
		catch(Exception e) {
			JOptionPane.showMessageDialog(null,"Invalid Item");
		}
		
		return null;
	}
	
	
	//Fetching all items
	public ArrayList<items> AllItems() {
		ArrayList<items> itemList=new ArrayList<items>();
		String sql="select * from items";
		try {
			result=state.executeQuery(sql);
			while(result.next()) {
				items it=new items();
				it.setId(result.getInt("id"));
				it.setName(result.getString("name"));
				it.setCategory(result.getString("category"));
				it.setPrice(result.getFloat("price"));
				it.setQunatity(result.getFloat("quantity"));
				itemList.add(it);
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		return itemList;
	}	
	
	
	//Verifying Login (NOT REUSABLE)
		public EmployeeCreate loginVerification(String id,String password) {
			try {
				String sql="select * from employee where id="+id+" and password='"+password+"'";
				result=state.executeQuery(sql);
				result.next();
				if(result.getInt("id")==Integer.parseInt(id) && result.getString("password").equals(password)) {
					EmployeeCreate it=new EmployeeCreate();
					it.setId(result.getInt("id"));
					it.setName(result.getString("name"));
					it.setPassword(result.getString("password"));
					it.setDesignation(result.getString("designation"));
					return it;
				}
				
			}
			catch(Exception e) {
				JOptionPane.showMessageDialog(null,"invalid id");
			}
			return null;
			
		}
	
	//ADD EMPLOYEE
		public void addEmployee(String name,String category,String designation) {
			String sql="insert into employee VALUES( null, '"+name+"', '"+category+"', '"+designation+"')";
			try {
				state.executeUpdate(sql);
			}
			catch(Exception e) {
				JOptionPane.showMessageDialog(null,"Wrong Id");
			}
		}
	//REMOVE EMPLOYEE
		public void removeEmployee(int id) {
			String sql="delete from employee where id="+id;
			try {
				state.executeUpdate(sql);
			}
			catch(Exception e) {
				JOptionPane.showMessageDialog(null,"Wrong Id");
			}
		}
		
		
		//UPDATING EMPLOYEE
		public void updateEmployee(int id, String name, String password, String designation) {
			String sql="update employee set name='"+name+"',password='"+password+"',designation='"+designation+"' where id="+id;
			try {
				state.executeUpdate(sql);
			}
			catch(Exception e) {
				JOptionPane.showMessageDialog(null,"Enter Valid Input");
			}
		}
		
		//FETCHING INDIVIDUAL EMPLOYEE
		public EmployeeCreate getEmployee(String employeeName) {
			String sql="select * from employee where name like '"+employeeName+"%'";
			EmployeeCreate em = new EmployeeCreate();
			try {
				result=state.executeQuery(sql);
				result.next();
				em.setId(result.getInt("id"));
				em.setName(result.getString("name"));
				em.setPassword(result.getString("password"));
				em.setDesignation(result.getString("designation"));
				return em;
			}
			catch(Exception e) {
				JOptionPane.showMessageDialog(null,"Invalid Item");
			}
			
			return null;
		}
		//Fetching all employee
		public ArrayList<EmployeeCreate> AllEmployee() {
		ArrayList<EmployeeCreate> employeeList=new ArrayList<EmployeeCreate>();
		String sql="select * from employee";
		try {
			result=state.executeQuery(sql);
			while(result.next()) {
				EmployeeCreate it=new EmployeeCreate();
				it.setId(result.getInt("id"));
				it.setName(result.getString("name"));
				it.setPassword(result.getString("password"));
				it.setDesignation(result.getString("designation"));
				employeeList.add(it);
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		return employeeList;
	}
	
	//UPDATING AFTER SALE (NOT REUSABLE)
	public void updateDataBase(int employeeId,float amount,ArrayList<items> itemList) {
		try {
		//UPDATING TRANSACTION
		String sqlInsertTransaction="insert into transaction values("+employeeId+","+amount+",'"+LocalDate.now()+"')";
		state.executeUpdate(sqlInsertTransaction);
		
		//UPDATING QUANTITY
		for(int i=0;i<itemList.size();i++) {
			String sqlUpdateItem="update items set quantity= (select quantity from items where name='"+itemList.get(i).getName()+"')-"+itemList.get(i).getQunatity()+" where id="+itemList.get(i).getId()+";";
			state.executeUpdate(sqlUpdateItem);
		}
		}
		catch(Exception e) {
			JOptionPane.showMessageDialog(null,"Error");
		}
	}

}
