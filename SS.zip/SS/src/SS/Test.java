package SS;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;

public class Test {

	public static void main(String[] args) {
		DataAccess da=new DataAccess();
		ResultSet result =da.fetchDate();
		try {
			String any=result.getDate("saleDate").toString();
			System.out.println(any);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(null,"WRONG 222");
		}
	}

}
