package SS;



import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.*;

import employee.EmployeeCreate;
import manager.Manager;

public class Login extends JFrame {
	private JPanel inLayer;
	private JButton btnLogin;
	private JButton btnClear;
	private JButton btnShowPassword;
	private Login log=this;
	private DataAccess da=new DataAccess();
	private JTextField userName;
	private JPasswordField password;
	private JLabel background;
	private JLabel new1;
	//giftitem,snacks,electronics,vegetable,spice,fish,meat,fruits,cosmetics,drinks,medicine,frozenitems
	boolean showPassword=false;
	EmployeeCreate employee;

	public Login() {
		
		setBounds(400,150,751,479);
		setTitle("Login");
		setLayout(null);
		
		
		inLayer= new JPanel();
		inLayer.setBounds(0,0,751,479);
		inLayer.setLayout(null);
		add(inLayer);
		
		 
		initComponents();
	}
	
	public void initComponents() {
		
		
		btnLogin=new JButton ("Login");
		btnLogin.setBounds(50,300,80,30);
		btnLogin.setBackground(Color.ORANGE);
		
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String loginCategory=null;			
				try {
					employee=da.loginVerification(userName.getText(),password.getText());
					loginCategory=employee.getDesignation();
					if(loginCategory!=null) {
						if(loginCategory.equals("Manager")) {
							Manager man=new Manager(log,employee);
							man.setVisible(true);
							log.setVisible(false);
						}
						if(loginCategory.equals("Salesman")) {
							Salesman man=new Salesman(log,employee);
							man.setVisible(true);
							log.setVisible(false);
						}
					}
				} 
				catch (Exception e1) {
					JOptionPane.showMessageDialog(null,"Please enter id and password");
				}
			}
		});
		inLayer.add(btnLogin);
		
		
		btnShowPassword= new JButton();
		btnShowPassword.setBounds(250,150,30,30);		
		btnShowPassword.setIcon(new ImageIcon("C:\\Users\\chmaitra\\Desktop\\SS\\image\\Off.png"));
		btnShowPassword.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(!showPassword) {
					showPassword=true;
					password.setEchoChar((char)0);
					btnShowPassword.setIcon(new ImageIcon("C:\\Users\\chmaitra\\Desktop\\SS\\image\\On.png"));
				}
				else {
					password.setEchoChar('*');
					showPassword=false;
					btnShowPassword.setIcon(new ImageIcon("C:\\Users\\chmaitra\\Desktop\\SS\\image\\Off.png"));
				}
				
			}
		});
		inLayer.add(btnShowPassword);
		
		
		


	    btnClear=new JButton("Clear");
	    btnClear.setBounds(150,300,80,30);
	    btnClear.setBackground(Color.ORANGE);
	    btnClear.addActionListener(new ActionListener() {
	    
	    public void actionPerformed(ActionEvent e) {
	    	userName.setText("");
	    	password.setText("");
	    	
	    	}
	    
	    });
	    
	    inLayer.add(btnClear);
	    
	    JLabel lblW= new JLabel();
	    lblW.setText("WELCOME TO PNP SUPERSHOP");
	    lblW.setBackground(Color.ORANGE);
	    lblW.setOpaque(true);
	    lblW.setFont(new Font("Lucida Handwriting",Font.BOLD,20));
	    lblW.setBounds(15,10,370,60);
	    inLayer.add(lblW);
	    
	    
	    
	    JLabel lbl1= new JLabel();
	    lbl1.setText("User ID:");
	    lbl1.setFont(new Font(Font.SERIF,Font.BOLD,18));
	    lbl1.setBounds(50,100,80,30);
	    inLayer.add(lbl1);
	    
	    JLabel lbl2= new JLabel();
	    lbl2.setText("Password:");
	    lbl2.setFont(new Font(Font.SERIF,Font.BOLD,18));
	    lbl2.setBounds(50,150,80,30);
	    inLayer.add(lbl2);
	    
	    userName=new JTextField("3");
		userName.setBounds(140,100,100,30);
		userName.setFont(new Font(Font.SERIF,Font.PLAIN,18));
		userName.setOpaque(false);
		userName.setForeground(Color.RED);
		inLayer.add(userName);
		
		password=new JPasswordField("abc");
		password.setBounds(140,150,100,30);
		password.setFont(new Font(Font.SERIF,Font.PLAIN,18));
		password.setForeground(Color.RED);
		password.setOpaque(false);
		inLayer.add(password);
		
		background=new JLabel(new ImageIcon("C:\\Users\\chmaitra\\Desktop\\SS\\src\\image\\LP.jpg"));
		background.setBounds(0,0,751,479);	
		inLayer.add(background);
	   
	   
	  
	}
}