package SS;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;

public class Splash extends Thread {

	SplashFrame splashFrame;
	public void run() {
		splashFrame = new SplashFrame();
		splashFrame.setVisible(true);
	}
}

class SplashFrame extends JFrame{
	JPanel panel1;
	JLabel welcome;
	JLabel percent;
	JProgressBar progress;
	public SplashFrame() {
		setBounds(400,150,500,400);
		setLayout(null);
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		panel1=new JPanel();
		panel1.setLayout(null);
		panel1.setBounds(0, 0, 700, 400);
		panel1.setBackground(Color.ORANGE);
		add(panel1);
		initComponent();
	}
	public void initComponent(){
		welcome=new JLabel("WELCOME TO PNP SUPER SHOP");
		welcome.setFont(new Font("Arial",Font.BOLD,30));
		welcome.setForeground(Color.white);
		welcome.setBounds(15,100,500,100);
		panel1.add(welcome);
		
		
		progress=new JProgressBar();
		progress.setBounds(20,320,460,40);
		panel1.add(progress);
		
		percent=new JLabel();
		percent.setBounds(230,370,30,20);
		panel1.add(percent);
	}
}
