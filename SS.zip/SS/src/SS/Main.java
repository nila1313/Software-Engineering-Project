package SS;

import javax.swing.JOptionPane;

public class Main {

	public static void main(String[] args) {
		try{
			Splash splash=new Splash();
			splash.run();
			for(int i=0;i<=100;i++) {
				splash.splashFrame.progress.setValue(i);
				splash.splashFrame.percent.setText(i+"%");
				Thread.sleep(18);
			}
			splash.splashFrame.dispose();
		}
		catch(Exception e) {
			JOptionPane.showMessageDialog(null, "Restart the program again");
		}
		Login loginNew=new Login();
		loginNew.setVisible(true);
	}

}
