package SS;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import employee.EmployeeCreate;
import items.ItemTableModel;
import items.items;

public class Salesman extends JFrame {
	JButton btnLogout;
	JButton btnAdd;
	JButton btnRemove;
	JButton btnUpdate;
	JButton btnConfirm;
	
	JPanel panel1;
	JTextField searchBox;
	JTextField quantityBox;
	JTextField Amount;
	JTable saleCart;
	JScrollPane viewTable;
	JLabel totalAmount;
	JLabel returnChange;
	JLabel background;
	
	private JTextField txt3;
	private double a,b,result;
	private String operation; 
	
	
	
	
	
	DataAccess da=new DataAccess();
	ItemTableModel model;
	
	Login login;
	Salesman man=this;
	ArrayList<items> itemList=new ArrayList<items>();
	EmployeeCreate employee;
	
	public Salesman(Login log,EmployeeCreate employee) {
		setBounds(50,50,700,700);
		setBounds(50,50,1000,700);
		setLayout(null);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		panel1=new JPanel();
		panel1.setLayout(null);
		panel1.setBounds(0,0,1000,700);
		add(panel1);
		
		this.login=log;
		initComponent();
		this.populateTable();
		this.employee=employee;
		
	}
	public void initComponent() {
		//BUTTONS 1
		btnLogout=new JButton();
		btnLogout.setBounds(940,20,40,40);
		btnLogout.setBackground(Color.pink);
		btnLogout.setIcon(new ImageIcon("C:\\Users\\chmaitra\\Desktop\\SS\\src\\image\\LO.png"));
		btnLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				login.setVisible(true);
				man.dispose();
			}
		});
		panel1.add(btnLogout);
		
		//2
		btnAdd = new JButton("Add");
		btnAdd.setBounds(100, 40,90,30);
		btnAdd.setBackground(Color.WHITE);
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addItems();
				totalAmount.setText(calculateTotalPrice()+"");
			}
		});
		panel1.add(btnAdd);
		
		//3
		btnRemove=new JButton("Remove");
		btnRemove.setBounds(240,40,90,30);
		btnRemove.setBackground(Color.pink);
		btnRemove.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for(int i=0;i<itemList.size();i++) {
					if(itemList.get(i).getName().toUpperCase().equals(searchBox.getText().toUpperCase())){
						itemList.remove(i);
					}
				}
				populateTable();
				totalAmount.setText(calculateTotalPrice()+"");
			}
		});
		panel1.add(btnRemove);
		
		//4
		btnUpdate=new JButton("Update");
		btnUpdate.setBounds(370,40,90,30);
		btnUpdate.setBackground(Color.WHITE);
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				updateItems();
				populateTable();
				totalAmount.setText(calculateTotalPrice()+"");
			}
		});
		panel1.add(btnUpdate);
		
		//5
		btnConfirm=new JButton();
		btnConfirm.setBounds(510,40,90,30);
		btnConfirm.setBackground(Color.pink);
		btnConfirm.setText("Confirm");
		btnConfirm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					returnChange.setText(Float.parseFloat(Amount.getText())-calculateTotalPrice()+"");//USING TRY CASUE OF PARSING
					confirmSale();
				}
				catch(Exception e) {
					JOptionPane.showMessageDialog(null,"Inter Valid Amount");
				}
			}
		});
		panel1.add(btnConfirm);
		
	
       //LABEL
		 JLabel lebelSearchBox= new JLabel();
		 lebelSearchBox.setText("Enter Name of Items:");
		 lebelSearchBox.setFont(new Font(Font.SERIF,Font.BOLD,20));
		 lebelSearchBox.setForeground(Color.WHITE);
		 lebelSearchBox.setBounds(700,150,200,30);
		 panel1.add(lebelSearchBox);
		
		 JLabel lebelQuantityBox= new JLabel();
		 lebelQuantityBox.setText("Enter Quantity:");
		 lebelQuantityBox.setFont(new Font(Font.SERIF,Font.BOLD,20));
		 lebelQuantityBox.setForeground(Color.WHITE);
		 lebelQuantityBox.setBounds(700,210,180,30);
		 panel1.add(lebelQuantityBox);
		 
		 JLabel lebelAmount= new JLabel();
		 lebelAmount.setText("Enter Amount:");
		 lebelAmount.setFont(new Font(Font.SERIF,Font.BOLD,20));
		 lebelAmount.setForeground(Color.WHITE);
		 lebelAmount.setBounds(700,270,180,30);
		 panel1.add(lebelAmount);
		
		 
		 JLabel lebelTotalAmount= new JLabel();
		 lebelTotalAmount.setText("Total Amount:");
		 lebelTotalAmount.setFont(new Font(Font.SERIF,Font.BOLD,30));
		 lebelTotalAmount.setForeground(Color.WHITE);
		 lebelTotalAmount.setBackground(Color.RED);
		 lebelTotalAmount.setOpaque(true);
		 lebelTotalAmount.setBounds(640,350,190,35);
		 panel1.add(lebelTotalAmount);
		 
		 
		 
		 JLabel lebelReturnChange= new JLabel();
		 lebelReturnChange.setText("Return change:");
		 lebelReturnChange.setFont(new Font(Font.SERIF,Font.BOLD,30));
		 lebelReturnChange.setForeground(Color.WHITE);
		 lebelReturnChange.setBackground(Color.RED);
		 lebelReturnChange.setOpaque(true);
		 lebelReturnChange.setBounds(640,390,200,35);
		 panel1.add(lebelReturnChange);
		
		 
		 totalAmount=new JLabel("0");
		 totalAmount.setBounds(860,330,120,70);
		 totalAmount.setForeground(Color.WHITE);
		 totalAmount.setFont(new Font(Font.SERIF,Font.BOLD,30));
		 panel1.add(totalAmount);
			
		 returnChange=new JLabel("0");
		 returnChange.setBounds(860,370,120,70);
		 returnChange.setForeground(Color.WHITE);
		 returnChange.setFont(new Font(Font.SERIF,Font.BOLD,30));
		 panel1.add(returnChange);
			
		
		//TEXTFIELDS
		searchBox=new JTextField("Onion");
		searchBox.setBounds(700,180,70, 30);	
		panel1.add(searchBox);
		
		quantityBox=new JTextField("4");
		quantityBox.setBounds(700,240,70, 30);
		//quantityBox.setOpaque(false);
		panel1.add(quantityBox);
		
		Amount=new JTextField("10");
		Amount.setBounds(700,300,70, 30);	
		panel1.add(Amount);
		
		
		
		//TABLE AND SCROLL PANE
		saleCart=new JTable();
		saleCart.setBackground(Color.pink);
		viewTable=new JScrollPane();
		viewTable.setBackground(Color.pink);
		viewTable.setBounds(100, 100,500,500);
		viewTable.setViewportView(saleCart);
		viewTable.setOpaque(false);
		panel1.add(viewTable);
		
		//SET BACKGROUND
		background=new JLabel(new ImageIcon("C:\\Users\\chmaitra\\Desktop\\SS\\src\\image\\SM.jpg"));
		background.setBounds(0,0,1000,700);	
		panel1.add(background);
	}
	
	public void populateTable() {
		model=new ItemTableModel();
		model.fixItem(itemList);
		saleCart.setModel(model);
	}
	
	public boolean searchItem(items it) {
		items temp;
		temp=da.getItem(it.getName());
		for(int i=0;i<itemList.size();i++) {
			if(itemList.get(i).getId()==it.getId()) {
				JOptionPane.showMessageDialog(null,"Item Already Added");
				return true;
			}
		}
		//Checking if the item is available
		if(temp.getQunatity()-it.getQunatity()>=0) {
			return false;
		}
		else {
			JOptionPane.showMessageDialog(null,"Item not available");
			return true;
		}
	}
	
	
	public void addItems() {
		try {
			items it=da.getItem(searchBox.getText());
			it.setQunatity(Float.parseFloat(quantityBox.getText()));
			if(!searchItem(it)) {
				itemList.add(it);
				populateTable();
			}
			}
			catch(Exception E) {
				JOptionPane.showMessageDialog(null,"invalid Quantity");
			}
	}
	public float calculateTotalPrice() {
		float amount=0;
		if(itemList!=null) {
			for(int i=0;i<itemList.size();i++) {
				amount=amount+itemList.get(i).getPrice()*itemList.get(i).getQunatity();
			}
		}
		return amount;
	}
	
	//UPDATE QUANTITY
	public void updateItems(){
		try {	
			items temp=da.getItem(searchBox.getText());
			for(int i=0;i<itemList.size();i++) {
				if(itemList.get(i).getId()==temp.getId() && temp.getQunatity()>=Float.parseFloat(quantityBox.getText())) {
					itemList.get(i).setQunatity(Float.parseFloat(quantityBox.getText()));
				}
				else {
					JOptionPane.showMessageDialog(null,"Invalid Item or Quantity");
				}
			}
		}
		catch(Exception e) {
			JOptionPane.showMessageDialog(null,"Invalid Quantity");
		}
	}
	
	//UPDATING DATABASE
	private void confirmSale() {
		if(itemList.size()>0) {
			short option=(short)JOptionPane.showConfirmDialog(null,"Are you sure?", "Sale Confirmation",JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE);
			if(option==0) {
				da.updateDataBase(employee.getId(),calculateTotalPrice(),itemList);
				itemList.clear();
				populateTable();
				searchBox.setText("");
				quantityBox.setText("");
				totalAmount.setText("0");
				returnChange.setText("0");
			}
		}
	}

}

