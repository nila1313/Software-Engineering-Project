package items;

import java.util.ArrayList;

import javax.swing.table.AbstractTableModel;

import SS.DataAccess;

public class ItemTableModel extends AbstractTableModel {
	private String[] colNames = {"id","name","category","price","quantity"};
	ArrayList<items> itemList=new ArrayList<items>(); //Cart
	DataAccess da=new DataAccess();
	
	//Setting All items
	public void allItems() {
		itemList = da.AllItems();
	}
	
	//Salesman Items
	public void fixItem(ArrayList<items> itemList) {
		this.itemList=itemList;
	}
	
	//Built in configuration 
	public int getColumnCount() {
		return colNames.length;
	}

	public int getRowCount() {
		return itemList.size();
	}
	
	public String getColumnName(int col) {
		return colNames[col];
	}

	public Object getValueAt(int row, int col) {
		if(itemList.size()==0)
			return null;
		
		try
		{
			items i = itemList.get(row);
			switch(col)
			{
				case 0:
					return i.getId();
				case 1:
					return i.getName();
				case 2:
					return i.getCategory();
				case 3:
					return i.getPrice();
				case 4:
					return i.getQunatity();
				default:
					return null;
			}
			
		}
		catch(Exception ex)
		{
			return null;
		}
	}

}
