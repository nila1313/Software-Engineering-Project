package Restaurant;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

public class SeeUserList extends JFrame{
	private JPanel pnlmgr;
	private JTable allUserList ;
	private JScrollPane spuser;
	private DataAccess d; 
	private UserTableModel utmodel;
	private JButton insert;
	private JButton delete;
	private JButton search;
	private JButton update;
	private JButton showAll;
	private JButton setValue;
	private JTextField userid;
	private JTextField name;
	private JTextField password;
	private JTextField type;
	private JLabel background;
	
	
	private ArrayList<User> uList = new ArrayList<User>();
    public SeeUserList() {
		super("User List"); 
    	setBounds(0,0,1200,800);
		 setLayout(null);
		 setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		 pnlmgr=new JPanel();
		 pnlmgr.setBounds(0,0,1200,800);
		 pnlmgr.setLayout(null);
		 add(pnlmgr);
		 employeeListComponents();
    }
    public void employeeListComponents() {
    	//table;
    	allUserList=new JTable();
    	spuser=new JScrollPane();
    	spuser.setBounds(200,200,800,250);
    	pnlmgr.add(spuser);
    	spuser.setViewportView(allUserList);
    	populateTableAllUser();
     
    	//Button;
    	this.insert= new JButton("CREATE");
		this.insert.setBounds(100,50, 150, 30);
		this.insert.setFont(new Font("SERIF", Font.PLAIN, 20));
		this.insert.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					String idS = userid.getText();
					int id = Integer.parseInt(idS);
					String username = name.getText();
					String pass = password.getText();
					String tpe = type.getText();
					String sql = "INSERT INTO user VALUES (" + id + ",'" + username + "','" + pass + "','" + tpe + "')";
					d.add(sql);
					populateTableAllUser();
				}
				catch (Exception e2) {
					JOptionPane.showMessageDialog(null, "Invalid Information");
				}
			}
		});
		this.pnlmgr.add(this.insert);
		
		this.delete= new JButton("DELETE");
		this.delete.setBounds(280,50, 150, 30);
		this.delete.setFont(new Font("SERIF", Font.PLAIN, 20));
		this.delete.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
				String idS=userid.getText();
				int uid = Integer.parseInt(idS);
				String sql="DELETE FROM user WHERE userid="+uid+"" ;
				d.delete(sql);
				populateTableAllUser();
				}
				catch (Exception e2) {
					JOptionPane.showMessageDialog(null, "Invalid Information");
				}
			}
		});
		this.pnlmgr.add(this.delete);
		
		this.search= new JButton("SEARCH");
		this.search.setBounds(450, 50, 150, 30);
		this.search.setFont(new Font("SERIF", Font.PLAIN, 20));
		this.search.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				try {
					String sql=null;
					String uid = userid.getText();
					String uName = name.getText();
					if (userid.getText().equals("")) {
						sql = " select * from user where username like '" + uName + "%'";
					}

					if (name.getText().equals("")) {
						int usrid = Integer.parseInt(uid);
						sql = " select * from user where userid=" + usrid;
					}

					
					if(!userid.getText().equals("") && !name.getText().equals("")){
						int usrid = Integer.parseInt(uid);
						sql = " select * from user where username like '" + uName + "%' and userid ="+usrid;
					}
					utmodel = new UserTableModel();
					utmodel.setUserList(d.GetUser(sql));
					allUserList.setModel(utmodel);
				} catch (Exception e2) {
					JOptionPane.showMessageDialog(null,"Invalid input");
				}
			}			
		});
		this.pnlmgr.add(this.search);
		
		this.update= new JButton("UPDATE");
		this.update.setBounds(620, 50, 150, 30);
		this.update.setFont(new Font("SERIF", Font.PLAIN, 20));
		this.update.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					String idS = userid.getText();
					int id = Integer.parseInt(idS);
					String username = name.getText();
					String pass = password.getText();
					String tpe = type.getText();
					String sql = "update user set userid='"+id+"',username='"+username+"',password='"+pass+"', type='"+tpe+"' where userid="+id;
					d.add(sql);
					populateTableAllUser();
				}
				catch (Exception e2) {
					JOptionPane.showMessageDialog(null, "Invalid Information");
				}
			}
		});
		this.pnlmgr.add(this.update);
		
		this.setValue= new JButton("SET ALL");
		this.setValue.setBounds(620, 100, 150, 30);
		this.setValue.setFont(new Font("SERIF", Font.PLAIN, 20));
		this.setValue.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					String sql=null;
					String uid = userid.getText();
					if (!userid.getText().equals("")) {
						int usrid = Integer.parseInt(uid);
						sql = " select * from user where userid=" + usrid;
						ArrayList<User> us=d.GetUser(sql);
						User u=us.get(0);
						name.setText(u.getUserName());
						password.setText(u.getPassword());
						type.setText(u.getType());
					}
				}
				catch (Exception e2) {
					JOptionPane.showMessageDialog(null, "Invalid Information");
				}
			}
		});
		this.pnlmgr.add(this.setValue);
		
		this.showAll= new JButton("SHOW ALL");
		this.showAll.setBounds(800, 50, 150, 30);
		this.showAll.setFont(new Font("SERIF", Font.PLAIN, 20));
		this.showAll.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				populateTableAllUser();
				
			}
		});
		this.pnlmgr.add(this.showAll);
		
		//text field
		this. userid = new JTextField();
		this. userid.setBounds(100, 10, 150, 30);
		this.pnlmgr.add(this. userid);
		
		this.name = new JTextField();
		this.name.setBounds(280, 10, 150, 30);
		this.pnlmgr.add(this.name);
		
		this.  password = new JTextField();
		this.  password.setBounds(450, 10, 150, 30);
		this.pnlmgr.add(this. password);
		
		this.type = new JTextField();
		this.type.setBounds(620, 10, 150, 30);
		this.pnlmgr.add(this.type);
		
		this.background=new JLabel(new ImageIcon("C:\\Users\\chmaitra\\eclipse-workspace\\Restaurant\\image\\UL.jpg"));
		this.background.setBounds(0,0,1200,800);	
		this.pnlmgr.add(background);
		
		
		}
     

	private void populateTableAllUser() {
		UserTableModel model=new UserTableModel();
		d=new DataAccess();
		String sql="select * from user";
		uList=d.GetUser(sql);
		model.setUserList( uList);
		allUserList.setModel(model);
	}
		
}
