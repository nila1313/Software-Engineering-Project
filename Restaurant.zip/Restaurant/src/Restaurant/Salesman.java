package Restaurant;

import javax.swing.*;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.util.ArrayList;

public class Salesman extends JFrame{
	private ArrayList<Menu> menus = new ArrayList<Menu>();
	private ArrayList<Menu> Selectedmenus = new ArrayList<Menu>();
	private DataAccess d; 
	private JPanel pnlsalesman;
	private JTable foodList;
	private JTable selectedfood;
	private JScrollPane sp;
	private JScrollPane spselected;
	private JTextField item;
	private JTextField quantity;
	private JTextField subTotal;
	private JLabel itemName;
	private JLabel quntty;
	private JLabel total;
	private JButton additem;
	private JButton remove;
	private JButton confirm;
	private JButton btnLogOut;
	private Salesman salesman=this;
	private Menu menu;
	private Login lin;
	private JLabel background;
	
	public Salesman(Login login) {
		super("Salesman");
		setBounds(0,0,1900,1188);
		 setLayout(null);
		 setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		 
		 pnlsalesman=new JPanel();
		 pnlsalesman.setBounds(0,0,1900,1188);//1188
		 pnlsalesman.setLayout(null);
		 add(pnlsalesman);
		 lin=login;
		 salesmanComponents();
	}
	private void salesmanComponents() {
		//textfield;
		item=new JTextField();
		item.setBounds(350,80, 200,50);
		pnlsalesman.add(item);
		
		quantity=new JTextField();
		quantity.setBounds(750,80,100,50);
		pnlsalesman.add(quantity);
		
		subTotal =new JTextField();
		subTotal.setBounds(1200,520,150,50);
	    pnlsalesman.add(subTotal);
		
		//table;
		foodList=new JTable();
		sp=new JScrollPane();
		sp.setBounds(200,200,800,250);
		pnlsalesman.add(sp);
		sp.setViewportView(foodList);
		
		selectedfood=new JTable();
		spselected=new JScrollPane();
		spselected.setBounds(1050,200,300,300);
		pnlsalesman.add(spselected);
		spselected.setViewportView(selectedfood);
		populateTableFullMenu();
		populateTableSelectedMenu();
		
		//Label;
		this.itemName= new JLabel("Food Name");
		this.itemName.setBounds(100, 80, 180, 50);
		this.itemName.setFont(new Font("SERIF", Font.PLAIN, 30));
		this.itemName.setForeground(Color.WHITE);
		this.itemName.setOpaque(true);
		this.itemName.setBackground(Color.RED);
		pnlsalesman.add(this.itemName);
		
		this.quntty= new JLabel("Quantity");
		this.quntty.setBounds(600, 80, 112, 50);
		this.quntty.setFont(new Font("SERIF", Font.PLAIN, 30));
		this.quntty.setForeground(Color.WHITE);
		this.quntty.setOpaque(true);
		this.quntty.setBackground(Color.RED);
		pnlsalesman.add(this.quntty);
		
		this.total= new JLabel("Total");
		this.total.setBounds(1100,520,80,50);
		this.total.setFont(new Font("SERIF",Font.PLAIN,30));
		this.total.setForeground(Color.WHITE);
		this.total.setOpaque(true);
		this.total.setBackground(Color.RED);
		
		pnlsalesman.add(this.total);
		
		//button;
		this.additem = new JButton("ADD ");
		this.additem.setBounds(900, 80, 150, 50);
		this.additem.setBackground(Color.RED);
		this.additem.setFont(new Font("SERIF", Font.PLAIN, 30));
		additem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					menu = d.getFoodName(item.getText());
					Selectedmenus.add(menu);
					populateTableSelectedMenu();
					menu.setQuantity(Integer.parseInt(quantity.getText()));
					totalPrice();
				} catch (Exception e2) {
					JOptionPane.showMessageDialog(null,"Enter Valid Quantity");
				}
			}
		});
		pnlsalesman.add(this.additem);
		
		this.confirm = new JButton("CONFIRM ");
		this.confirm.setBounds(1100,600,180, 50);
		this.confirm.setBackground(Color.RED);
		this.confirm.setFont(new Font("SERIF", Font.PLAIN, 30));
		confirm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String sql="insert into record values(null,"+subTotal.getText()+",'"+LocalDate.now()+"')";
				d.add(sql);	
				item.setText("");
				quantity.setText("");
				subTotal.setText("");
				Selectedmenus.clear();
				selectedfood.setModel(new MenuTableModel());
			}
		});
		pnlsalesman.add(this.confirm);
		
		this.btnLogOut = new JButton("LOG OUT");
		this.btnLogOut.setBounds(900, 600, 180, 50);
		this.btnLogOut.setBackground(Color.RED);
		this.btnLogOut.setFont(new Font("SERIF", Font.PLAIN, 30));
		this.btnLogOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				salesman.dispose();
				lin.setVisible(true);
				
			}
		});
		this.pnlsalesman.add(btnLogOut);
		
		this.remove = new JButton("REMOVE");
		this.remove.setBounds(1100, 80, 180, 50);
		this.remove.setBackground(Color.RED);
		this.remove.setFont(new Font("SERIF", Font.PLAIN, 30));
		this.remove.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String s=item.getText();
				for(int i=0;i<Selectedmenus.size();i++) {
					if(Selectedmenus.get(i).getFoodName().equals(s)) {
						Selectedmenus.remove(i);
						populateTableSelectedMenu();
						totalPrice();
					}
				}
				
			}
		});
		this.remove.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				
			}
		});
		this.pnlsalesman.add(remove);
		
		this.background=new JLabel(new ImageIcon("C:\\Users\\chmaitra\\eclipse-workspace\\Restaurant\\image\\Salesman.jpg"));
		this.background.setBounds(0,0,1900,1188);	
		this. pnlsalesman.add(background);
		
	}
	
	private void populateTableFullMenu() {
		MenuTableModel model=new MenuTableModel();
		d=new DataAccess();
		String query= "SELECT * FROM `menu`";
		menus=d.GetMenu(query);
		model.setMenuList(menus);
		foodList.setModel(model);
	}
	
	private void populateTableSelectedMenu() {
		MenuTableModel model=new MenuTableModel();
		model.setMenuList(Selectedmenus);
		selectedfood.setModel(model);
	}
	public void totalPrice() {
		int p,q;
		int t=0;
		for (int i = 0; i < Selectedmenus.size(); i++) {
			p=Selectedmenus.get(i).getPrice();
			q=Selectedmenus.get(i).getQuantity();
			t=t+(p*q);			
		}
		subTotal.setText(""+t+"");
	}
	
}
