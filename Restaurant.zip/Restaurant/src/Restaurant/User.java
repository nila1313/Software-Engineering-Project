package Restaurant;

public class User {
	private  int userId;
	private String userName;
	private String password;
	private String type;
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserName() {
		return userName;
	}
	
	public void setPassword(String password) {
		this.password= password;
	}
	public String getPassword() {
		return password;
	}
	
	
	public void setType(String type) {
		this.type = type;
	}
	public String getType() {
		return type;
	}
	
	@Override
	public String toString() {
		return "Menu [userId=" + userId + ", userName=" + userName+ ", password=" + password+ ",userType=" + type
				+ "]";
	}
	
}
