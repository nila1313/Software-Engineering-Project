package Restaurant;

import java.util.ArrayList;

import javax.swing.table.AbstractTableModel;

public class AllFoodList extends AbstractTableModel{

	ArrayList<Menu> menuList=new ArrayList<Menu>();
	
	String[] columnNames= {"Serial Number","Name","Type","Price"};
	public void setMenuList(ArrayList<Menu> menuList) {
		this.menuList=menuList;
	}
	
	public String getColumnName(int col) {
		return columnNames[col];
	}
	
	@Override
	public int getColumnCount() {
		return columnNames.length;
	}

	@Override
	public int getRowCount() {
		return menuList.size();
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
			switch(columnIndex) {
			case 0:
				return menuList.get(rowIndex).getFoodId();
			case 1:
				return menuList.get(rowIndex).getFoodName();
			case 2:
				return menuList.get(rowIndex).getFoodType();
			case 3:
				return menuList.get(rowIndex).getPrice();
			default:
				return null;
			}
	}

	

}