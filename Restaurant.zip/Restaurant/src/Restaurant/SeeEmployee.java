package Restaurant;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

public class SeeEmployee extends JFrame{
	private JPanel pnlmgr;
	private JTable allEmployeeList ;
	private JScrollPane spemp;
	private DataAccess d; 
	private EmployeeTableModel etm;
	private EmployeeTableModel emp;
	private JButton insert;
	private JButton delete;
	private JButton search;
	private JButton update;
	private JButton showAll;
	private JButton setValue;
	private JTextField employeeid;
	private JTextField name;
	private JTextField designation;
	private JTextField salary;
	
	private JLabel background;
	
	
	private ArrayList<EmployeeList> empList = new ArrayList<EmployeeList>();
    public SeeEmployee() {
	  super("Employee List");
    	setVisible(true);
	  setBounds(0,0,1200,800);
	  setLayout(null);
	 setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	 pnlmgr=new JPanel();
	 pnlmgr.setBounds(0,0,1200,800);
	 pnlmgr.setLayout(null);
	 add(pnlmgr);
	 employeeListComponents();
}
    public void employeeListComponents() {
     //table;
    allEmployeeList=new JTable();
    spemp=new JScrollPane();
    spemp.setBounds(200,200,800,250);
    pnlmgr.add(spemp);
    spemp.setViewportView(allEmployeeList);
     populateTableAllEmployee();
     
 	//Button;
 	this.insert= new JButton("CREATE");
		this.insert.setBounds(100,50, 150, 30);
		this.insert.setFont(new Font("SERIF", Font.PLAIN, 20));
		this.insert.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					String idS = employeeid.getText();
					int id = Integer.parseInt(idS);
					String empname = name.getText();
					String dgn = designation.getText();
					String salS= salary.getText();
					int sal = Integer.parseInt(salS);
					String sql = "INSERT INTO employee VALUES (" + id + ",'" + empname + "','" + dgn + "','" + sal+ "')";
					d.add(sql);
					populateTableAllEmployee();
				}
				catch (Exception e2) {
					JOptionPane.showMessageDialog(null, "Invalid Information");
				}
			}
		});
		this.pnlmgr.add(this.insert);
		
		this.delete= new JButton("DELETE");
		this.delete.setBounds(280,50, 150, 30);
		this.delete.setFont(new Font("SERIF", Font.PLAIN, 20));
		this.delete.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
				String idS=employeeid.getText();
				int empid = Integer.parseInt(idS);
				String sql="DELETE FROM employee WHERE employeeid="+empid+"" ;
				d.delete(sql);
				populateTableAllEmployee();
				}
				catch (Exception e2) {
					JOptionPane.showMessageDialog(null, "Invalid Information");
				}
			}
		});
		this.pnlmgr.add(this.delete);
		
		this.search= new JButton("SEARCH");
		this.search.setBounds(450, 50, 150, 30);
		this.search.setFont(new Font("SERIF", Font.PLAIN, 20));
		this.search.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					String sql=null;
					String fid = employeeid.getText();
					String fName = name.getText();
					if (employeeid.getText().equals("")) {
						sql = " select * from employee where employeename like '" + fName + "%'";
					}

					if (name.getText().equals("")) {
						int fdid = Integer.parseInt(fid);
						sql = " select * from employee where employeeid=" + fdid;
					}

					
					if(!employeeid.getText().equals("") && !name.getText().equals("")){
						int fdid = Integer.parseInt(fid);
						sql = " select * from employee where employeename like '" + fName + "%' and employeeid ="+fdid;
					}
					emp = new EmployeeTableModel();
					emp.setEmployeeList(d.GetEmployee(sql));
				    allEmployeeList.setModel(emp);
				} catch (Exception e2) {
					JOptionPane.showMessageDialog(null,"Invalid input");
				}
				
			}
		});
		this.pnlmgr.add(this.search);
		
		this.update= new JButton("UPDATE");
		this.update.setBounds(620, 50, 150, 30);
		this.update.setFont(new Font("SERIF", Font.PLAIN, 20));
		this.update.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					String idS = employeeid.getText();
					int id = Integer.parseInt(idS);
					String empname = name.getText();
					String emptype = designation.getText();
					String s = salary.getText();
					int eSalary = Integer.parseInt(s);
					String sql = "update employee set employeeid='"+id+"',employeename='"+empname+"',designation='"+emptype+"', salary="+eSalary+" where employeeid="+id;
					d.add(sql);
					populateTableAllEmployee();
				}
				catch (Exception e2) {
					JOptionPane.showMessageDialog(null, "Invalid Information");
				}
					
				
			}
		});
		this.pnlmgr.add(this.update);
		

		this.setValue= new JButton("SET ALL");
		this.setValue.setBounds(620, 100, 150, 30);
		this.setValue.setFont(new Font("SERIF", Font.PLAIN, 20));
		this.setValue.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					String sql=null;
					String eid = employeeid.getText();
					if (!employeeid.getText().equals("")) {
						int fdid = Integer.parseInt(eid);
						sql = " select * from employee where employeeid=" + fdid;
						ArrayList<EmployeeList> us=d.GetEmployee(sql);
						EmployeeList u=us.get(0);
						name.setText(u.getEmployeeName());
						designation.setText(u.getDesignation());
						salary.setText(String.valueOf((u.getSalary())));
					}
				}
				catch (Exception e2) {
					JOptionPane.showMessageDialog(null, "Invalid Information");
				}
			}
		});
		this.pnlmgr.add(setValue);
		
		this.showAll= new JButton("SHOW ALL");
		this.showAll.setBounds(800, 50, 150, 30);
		this.showAll.setFont(new Font("SERIF", Font.PLAIN, 20));
		this.showAll.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				populateTableAllEmployee();
				
			}
		});
		this.pnlmgr.add(this.showAll);
		
		//text field;
				this. employeeid = new JTextField();
				this.employeeid.setBounds(100, 10, 150, 30);
				this.pnlmgr.add(this.employeeid);
				
				this.name = new JTextField();
				this.name.setBounds(280, 10, 150, 30);
				this.pnlmgr.add(this.name);
				
				this. designation = new JTextField();
				this.  designation.setBounds(450, 10, 150, 30);
				this.pnlmgr.add(this. designation);
				
				this.salary = new JTextField();
				this.salary.setBounds(620, 10, 150, 30);
				this.pnlmgr.add(this.salary);
				
				this.background=new JLabel(new ImageIcon("C:\\Users\\chmaitra\\eclipse-workspace\\Restaurant\\image\\EL.jpg"));
				this.background.setBounds(0,0,1200,800);	
				this.pnlmgr.add(background);
				
}
private void populateTableAllEmployee() {
	EmployeeTableModel model=new EmployeeTableModel();
	d=new DataAccess();
	String q="SELECT * FROM `employee`";
	 empList=d.GetEmployee(q);
	model.setEmployeeList( empList);
	allEmployeeList.setModel(model);
}
}
