package Restaurant;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class Login extends JFrame {
	private JLabel lblUserName;
	private JLabel lblPassword;
	private JTextField txtUserName;
	private JPasswordField txtPassword;
	private JButton btnLogin;
	private JLabel background;
	private DataAccess d; 
	private Login lin =this;
	public Login() {
		//Login frame;
		// setVisible(true);
		super("Login");
		setBounds(300,300,800,533);
		setLayout(null);
		 setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.loginComponents();
	
	 }
	 private void loginComponents() {
		//login label;
		this.lblUserName= new JLabel("User Name:");
		this.lblUserName.setBounds(400, 300, 140, 40);
		this.lblUserName.setBackground(Color.RED);
		this.lblUserName.setForeground(Color.WHITE);
		this.lblUserName.setOpaque(true);
		this.lblUserName.setFont(new Font("Snap ITC", Font.ITALIC, 20));
		this.add(this.lblUserName);
		
		this.lblPassword= new JLabel("Password:");
		this.lblPassword.setBounds(400, 350, 130, 40);
		this.lblPassword.setBackground(Color.RED);
		this.lblPassword.setForeground(Color.WHITE);
		this.lblPassword.setOpaque(true);
		this.lblPassword.setFont(new Font("Snap ITC", Font.ITALIC, 20));
		this.add(this.lblPassword);
		
		//login text field;
		this.txtUserName = new JTextField("William");
		this.txtUserName.setBounds(550,300, 150, 40);
		this.add(this.txtUserName);
		this.txtPassword = new JPasswordField("102");
		this.txtPassword.setBounds(550, 350, 150, 40);
		this.add(this.txtPassword);
		
		//login button;
		this.btnLogin = new JButton("Login");
		this.btnLogin.setBounds(450, 410, 150, 30);
		this.btnLogin.setFont(new Font("Snap ITC", Font.ITALIC, 20));
		this.btnLogin.setBackground(Color.ORANGE);
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 d=new DataAccess();
				 if(d.checkLogin(txtUserName.getText(), txtPassword.getText())) {
					if(d.checkUserType(txtUserName.getText(), txtPassword.getText()).equals("salesman")) {
						Salesman sman=new Salesman(lin);
						sman.setVisible(true);
						setVisible(false);
						
					}
					if(d.checkUserType(txtUserName.getText(), txtPassword.getText()).equals("manager")) {
						Manager m=new Manager(lin);
						m.setVisible(true);
						setVisible(false);
						
					}
				 }
			}
		});
		this.add(this.btnLogin);
		
		this.background=new JLabel(new ImageIcon("C:\\Users\\chmaitra\\eclipse-workspace\\Restaurant\\image\\Login.jpg"));
		this.background.setBounds(0,0,800,533);	
		this.add(background);
	 }
 }
