package Restaurant;

public class Record {
	int amount;
	String date;
}
