package Restaurant;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.*;

import com.toedter.calendar.JDateChooser;

public class Manager extends JFrame {
     private JButton btnEmployee;
     private JButton btnFood;
     private JButton btnUser;
     private JButton btnShow;
     private JButton btnLogOut;
     private JTable showDate;
	 private EmployeeTableModel etm;
     private JPanel pnlmgr;
     private SeeEmployee list;
     private FoodList foodList;
     private SeeUserList userlist;
	 private JScrollPane sp;
	 private Manager manager =this;
	 JDateChooser date;
	 private Login lin;
	 private JLabel background;
		
 public Manager(Login login) {
	 //Mgr frame;
	  //setVisible(true);
	super("Manager");	
	 setBounds(0,0,900,600);
		setLayout(null);
		 setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		  this.managerComponents();
		  lin=login;

       }
 
 public void managerComponents() {
	//Manager button;
	this
	.btnEmployee = new JButton("EMPLOYEE LIST");
	this.btnEmployee.setBounds(20, 100, 250, 30);
	this.btnEmployee.setFont(new Font("Snap ITC", Font.ITALIC, 20));
	this.btnEmployee.setForeground(Color.WHITE);
	this.btnEmployee.setOpaque(true);
	this.btnEmployee.setBackground(Color.RED);
	btnEmployee.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			list=new SeeEmployee();
		}
	});
	this.add(this.btnEmployee);
	
	this.btnFood = new JButton("FOOD LIST");
	this.btnFood.setBounds(20, 160, 250, 30);
	this.btnFood.setFont(new Font("Snap ITC", Font.ITALIC, 20));
	this.btnFood.setForeground(Color.WHITE);
	this.btnFood.setOpaque(true);
	this.btnFood.setBackground(Color.RED);
	btnFood.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			 foodList=new FoodList();
		}
	});
	this.add(this.btnFood);
	
	this.btnUser = new JButton("USER LIST");
	this.btnUser.setBounds(20, 210, 250, 30);
	this.btnUser.setFont(new Font("Snap ITC", Font.ITALIC, 20));
	this.btnUser.setForeground(Color.WHITE);
	this.btnUser.setOpaque(true);
	this.btnUser.setBackground(Color.RED);
	btnUser.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			userlist=new SeeUserList();
			userlist.setVisible(true);
			
		}
	});
	this.add(this.btnUser);
	
	
	
	this.btnShow=new JButton("SHOW");
	this.btnShow.setBounds(400,30,130,60);
	this.btnShow.setFont(new Font("Snap ITC", Font.ITALIC, 20));
	this.btnShow.setForeground(Color.WHITE);
	this.btnShow.setOpaque(true);
	this.btnShow.setBackground(Color.RED);
	this.btnShow.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			try {
				Date time = date.getDate();
				SimpleDateFormat fdate = new SimpleDateFormat("yyyy-MM-dd");
				String key = fdate.format(time);
				RecordTableModel model=new RecordTableModel(key);
		 		showDate.setModel(model);
			} catch (Exception e2) {
				JOptionPane.showMessageDialog(null,"Please insert a date");
			}
			
		}
	});
	this.add(this.btnShow);
	
	
	this.showDate=new JTable();
	this.sp=new JScrollPane();
	this.sp.setBounds(400,100,300,400);
	this.sp.setViewportView(showDate);
	this.add(sp);
	this.populateTable();
	
	
	this.date=new JDateChooser();
	this.date.setBounds(550,30,130,60);
	this.add(date);
	

	this.btnLogOut = new JButton("LOGOUT");
	this.btnLogOut.setBounds(20, 270, 250, 30);
	this.btnLogOut.setFont(new Font("Snap ITC", Font.ITALIC, 20));
	this.btnLogOut.setFont(new Font("Snap ITC", Font.ITALIC, 20));
	this.btnLogOut.setForeground(Color.WHITE);
	this.btnLogOut.setOpaque(true);
	this.btnLogOut.setBackground(Color.RED);
	this.btnLogOut.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			manager.dispose();
			lin.setVisible(true);
			
		}
	});
	this.add(this.btnLogOut);
	
	this.background=new JLabel(new ImageIcon("C:\\Users\\chmaitra\\eclipse-workspace\\Restaurant\\image\\Manager.jpg"));
	this.background.setBounds(0,0,900,600);	
	this.add(background);
	
 	}
 	public void populateTable() {
 		RecordTableModel model=new RecordTableModel("");
 		this.showDate.setModel(model);
 	}

 }


