package Restaurant;

import java.util.ArrayList;

import javax.swing.table.AbstractTableModel;

public class RecordTableModel extends AbstractTableModel{
	DataAccess d=new DataAccess();
	String[] columnNames= {"Total","Time"};
	ArrayList<Record> list=new ArrayList<Record>();
	public RecordTableModel(String key) {
		String sql="select sum(amount) as total,time from record where time>='"+key+"' group by time ";
		if(key.equals("")) {
			sql="select sum(amount) as total,time from record group by time order by time desc";
		}
		list=d.getRecord(sql);
	}
	
	public String getColumnName(int col) {
		return columnNames[col];
	}
	
	@Override
	public int getColumnCount() {
		return columnNames.length;
	}

	@Override
	public int getRowCount() {
		return list.size();
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		switch(columnIndex) {
		case 0:
			return list.get(rowIndex).amount;
		case 1:
			return list.get(rowIndex).date;
		default:
			return null;
		}
	}
	
}
