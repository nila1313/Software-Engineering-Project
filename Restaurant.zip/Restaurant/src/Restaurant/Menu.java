package Restaurant;

public class Menu {
	private int foodId;
	private String foodName;
	private String foodType;
	private int price;
	private int quantity;
	
	
	public int getFoodId() {
		return foodId;
	}
	public void setFoodId(int foodId) {
		this.foodId = foodId;
	}
	public String getFoodName() {
		return foodName;
	}
	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}
	public String getFoodType() {
		return foodType;
	}
	public void setFoodType(String foodType) {
		this.foodType = foodType;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "Menu [foodId=" + foodId + ", foodName=" + foodName + ", foodType=" + foodType + ", price=" + price
				+ ", quantity=" + quantity + "]";
	}
}
