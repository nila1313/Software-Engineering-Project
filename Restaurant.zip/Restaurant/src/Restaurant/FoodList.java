package Restaurant;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

public class FoodList extends JFrame{
	private JPanel pnlFood;
	private JTable allFoodList ;
	private JScrollPane spemp;
	private DataAccess d; 
	private AllFoodList food;
	private JButton insert;
	private JButton delete;
	private JButton search;
	private JButton update;
	private JButton setValue;
	private JButton showAll;
	private JTextField foodid;
	private JTextField name;
	private JTextField type;
	private JTextField price;
	private JLabel background;
	
	private ArrayList<Menu> menus = new ArrayList<Menu>();
	public FoodList() {
		super("Food List");
		 setVisible(true);
		  setBounds(0,0,1200,800);
		  setLayout(null);
		 setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		 pnlFood=new JPanel();
		 pnlFood.setBounds(0,0,1900,1000);
		 pnlFood.setLayout(null);
		 add(pnlFood);
		 foodListComponents();
	}
	private void foodListComponents() {
		//table;
		allFoodList=new JTable();
		spemp=new JScrollPane();
		spemp.setBounds(200,200,800,250);
		pnlFood.add(spemp);
		spemp.setViewportView(allFoodList);
		populateTableFullMenu() ;
		
		//Button;
    	this.insert= new JButton("CREATE");
		this.insert.setBounds(100,50, 150, 30);
		this.insert.setFont(new Font("SERIF", Font.PLAIN, 20));
		this.insert.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					String idS = foodid.getText();
					int id = Integer.parseInt(idS);
					String foodname = name.getText();
					String fdtype = type.getText();
					String foodprice = price.getText();
					int p = Integer.parseInt(foodprice);
					String sql = "INSERT INTO menu VALUES (" + id + ",'" + foodname + "','" + fdtype + "','" + p + "')";
					d.add(sql);
					populateTableFullMenu();
				}
				catch (Exception e2) {
					JOptionPane.showMessageDialog(null, "Invalid Information");
				}
			}
		});
		this.pnlFood.add(this.insert);
		
		this.delete= new JButton("DELETE");
		this.delete.setBounds(280,50, 150, 30);
		this.delete.setFont(new Font("SERIF", Font.PLAIN, 20));
		this.delete.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
				String fname=name.getText();
				String sql="DELETE FROM menu WHERE foodname='"+fname+"'" ;
				d.delete(sql);
				populateTableFullMenu();
				}
				catch (Exception e2) {
					JOptionPane.showMessageDialog(null, "Invalid Information");
				}
			}
		});
		this.pnlFood.add(this.delete);
		
		this.search= new JButton("SEARCH");
		this.search.setBounds(450, 50, 150, 30);
		this.search.setFont(new Font("SERIF", Font.PLAIN, 20));
		this.search.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					String q=null;
					String fid = foodid.getText();
					String fName = name.getText();
					if (foodid.getText().equals("")) {
						q = " select * from menu where foodname like '" + fName + "%'";
					}

					if (name.getText().equals("")) {
						int fdid = Integer.parseInt(fid);
						q = " select * from menu where foodid= "+ fdid;
					}

					
					if(!foodid.getText().equals("") && !name.getText().equals("")){
						int fdid = Integer.parseInt(fid);
						q = " select * from menu where foodname like '" + fName + "%' and foodid ="+fdid;
					}
					food = new AllFoodList();
					food.setMenuList(d.GetMenu(q));
					allFoodList.setModel(food);
				} catch (Exception e2) {
					JOptionPane.showMessageDialog(null,"Invalid input");
				}
				
			}
		});
		this.pnlFood.add(this.search);
		
		this.update= new JButton("UPDATE");
		this.update.setBounds(620, 50, 150, 30);
		this.update.setFont(new Font("SERIF", Font.PLAIN, 20));
		this.update.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					String idS = foodid.getText();
					int id = Integer.parseInt(idS);
					String fname = name.getText();
					String ftype = type.getText();
					String p = price.getText();
					int fprice = Integer.parseInt(p);
					String sql = "update menu set foodid='"+id+"',foodname='"+fname+"',foodtype='"+ftype+"', price="+fprice+" where foodid="+id;
					d.add(sql);
					populateTableFullMenu();
				}
				catch (Exception e2) {
					JOptionPane.showMessageDialog(null, "Invalid Information111");
				}
				
			}
		});
		this.pnlFood.add(this.update);
		this.setValue= new JButton("SET ALL");
		this.setValue.setBounds(620, 100, 150, 30);
		this.setValue.setFont(new Font("SERIF", Font.PLAIN, 20));
		this.setValue.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					String sql=null;
					String fid = foodid.getText();
					if (!foodid.getText().equals("")) {
						int fdid = Integer.parseInt(fid);
						sql = " select * from menu where foodid=" + fdid;
						ArrayList<Menu> us=d.GetMenu(sql);
						Menu u=us.get(0);
						name.setText(u.getFoodName());
						type.setText(u.getFoodType());
						price.setText(String.valueOf((u.getPrice())));
					}
				}
				catch (Exception e2) {
					JOptionPane.showMessageDialog(null, "Invalid Information");
				}
			}
		});
		this.pnlFood.add(setValue);
		
		this.showAll= new JButton("SHOW ALL");
		this.showAll.setBounds(800, 50, 150, 30);
		this.showAll.setFont(new Font("SERIF", Font.PLAIN, 20));
		this.showAll.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				populateTableFullMenu();
				
			}
		});
		this.pnlFood.add(this.showAll);
		
		//text field;
				this.foodid = new JTextField();
				this.foodid.setBounds(100, 10, 150, 30);
				this.pnlFood.add(this. foodid);
				
				this.name = new JTextField();
				this.name.setBounds(280, 10, 150, 30);
				this.pnlFood.add(this.name);
				
				this.type= new JTextField();
				this.type.setBounds(450, 10, 150, 30);
				this.pnlFood.add(this. type);
				
				this.price = new JTextField();
				this.price.setBounds(620, 10, 150, 30);
				this.pnlFood.add(this.price);
	
				this.background=new JLabel(new ImageIcon("C:\\Users\\chmaitra\\eclipse-workspace\\Restaurant\\image\\FL.jpg"));
				this.background.setBounds(0,0,1200,800);	
				this.pnlFood.add(background);
				
	
	}
	private void populateTableFullMenu() {
		AllFoodList model=new AllFoodList();
		d=new DataAccess();
		String sql=" select * from menu" ;
		menus=d.GetMenu(sql);
		model.setMenuList(menus);
		allFoodList.setModel(model);
	}
	

}
