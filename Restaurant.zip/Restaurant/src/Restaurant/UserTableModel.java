package Restaurant;

import java.util.ArrayList;

import javax.swing.table.AbstractTableModel;

public class UserTableModel extends AbstractTableModel{

	ArrayList<User> userList=new ArrayList<User>();
	
	String[] columnNames= {"User ID","User Name","Password","User Type"};
	public void setUserList(ArrayList<User> userList) {
		this.userList=userList;
	}
	
	public String getColumnName(int col) {
		return columnNames[col];
	}
	
	@Override
	public int getColumnCount() {
		return columnNames.length;
	}

	@Override
	public int getRowCount() {
		return userList.size();
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
			switch(columnIndex) {
			case 0:
				return userList.get(rowIndex).getUserId();
			case 1:
				return userList.get(rowIndex).getUserName();
			case 2:
				return userList.get(rowIndex).getPassword();
			case 3:
				return userList.get(rowIndex).getType();
			default:
				return null;
			}
	}

	

}
