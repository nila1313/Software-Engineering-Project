package Restaurant;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;


public class DataAccess {
	private Connection connection;
	private Statement statement;
	private ResultSet resultset;
	private Menu m;
	
	public DataAccess(){
		try {
			connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/restaurant", "root", "");
			statement = (Statement)connection.createStatement();
		}
		catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
		
	}
	
	public boolean checkLogin(String name, String pass){
		String sql = "Select * from user where username = '" + name + "' and password ='" + pass + "'";
		try{
			resultset = statement.executeQuery(sql);
			if(resultset.next()){
				return true;
			}
		}
		catch (SQLException e){
			JOptionPane.showMessageDialog(null, "Invalid Id or password");
		}
		return false;
	}
	public String checkUserType(String name,String pass)
	{
		String sql = "Select type from user where username = '" + name + "' and password ='" + pass + "'";
		try{
			resultset = statement.executeQuery(sql);
			if(resultset.next()){
				return resultset.getString("type");
			}
		}
		catch (SQLException e){
			JOptionPane.showMessageDialog(null, "Invalid Id or Password");
		}
		
		return null;
	}
	public ArrayList<Menu> GetMenu(String sqlMenu){
		ArrayList<Menu> list = new ArrayList<Menu>();
		
		try{
			resultset = statement.executeQuery(sqlMenu);
			while(resultset.next())
			{
				Menu menu = new Menu();
				menu.setFoodId(resultset.getInt("foodid"));
				menu.setFoodName(resultset.getString("foodname"));
				menu.setFoodType(resultset.getString("foodtype"));
				menu.setPrice(resultset.getInt("price"));
				list.add(menu);
			}
		}
		catch (Exception e){
			JOptionPane.showMessageDialog(null,"Invalid Error");
		}
		return list;
	}
	public Menu getFoodName(String name) {
		m=new Menu();
		String sql = "Select * from menu where foodname ='" + name +"'";
		try{
			resultset = statement.executeQuery(sql);
			if(resultset.next()) {
				m.setFoodName(resultset.getString("foodname"));
				m.setFoodId(resultset.getInt("foodid"));
				m.setFoodType(resultset.getString("foodtype"));
				m.setPrice(resultset.getInt("price"));
				return m;
			}
		}
		catch (SQLException e){
			JOptionPane.showMessageDialog(null, "NOT MATCH");
		}
		return null;
	}
	
	public ArrayList<EmployeeList> GetEmployee(String s){
		ArrayList<EmployeeList> list = new ArrayList<EmployeeList>();
		//String sqlEmp=("SELECT * FROM `employee`" );
		try{
			resultset = statement.executeQuery(s);
			while(resultset.next())
			{
				EmployeeList emp = new EmployeeList();
				emp.setEmployeeId(resultset.getInt("employeeid"));
				emp.setEmployeeName(resultset.getString("employeename"));
				emp.setDesignation(resultset.getString("designation"));
				emp.setSalary(resultset.getInt("salary"));
				list.add(emp);
			}
		}
		catch (Exception e){
			JOptionPane.showMessageDialog(null,"Invalid Error");
		}
		return list;
	}
	
	public ArrayList<User> GetUser(String sqlUser){
		ArrayList<User> userlist = new ArrayList<User>();
		try{
			resultset = statement.executeQuery(sqlUser);
			while(resultset.next())
			{
				User u = new User();
				u.setUserId(resultset.getInt("userid"));
				u.setUserName(resultset.getString("username"));
				u.setPassword(resultset.getString("password"));
				u.setType(resultset.getString("type"));
				userlist.add(u);
			}
		}
		catch (Exception e){
			JOptionPane.showMessageDialog(null,"Invalid Error");
		}
		return userlist;
	}
	
    public void add(String sql) {
		try{
			statement.executeUpdate(sql);
			
		}
		catch (SQLException e){
			JOptionPane.showMessageDialog(null, "Invalid Information");
		}
		
	
		
	}	
	public void delete(String sql) {
		try{
			statement.executeUpdate(sql);	
		}
		catch (SQLException e){
			JOptionPane.showMessageDialog(null, "Invalid Information");
		}
	}
	
	public ArrayList<Record> getRecord(String sql) {
		ArrayList<Record> list=new ArrayList<Record>();
		try {
			resultset=statement.executeQuery(sql);
			while (resultset.next()) {
				Record re = new Record();
				re.amount = resultset.getInt("total");
				re.date = resultset.getString("time");
				list.add(re);
			}
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}
	
}









