package Restaurant;

import java.util.ArrayList;

import javax.swing.table.AbstractTableModel;

public class EmployeeTableModel extends AbstractTableModel{

	ArrayList<EmployeeList> employeeList=new ArrayList<EmployeeList>();
	
	String[] columnNames= {"Employee ID","Name","Designation","Salary"};
	public void setEmployeeList(ArrayList<EmployeeList> employeeList) {
		this.employeeList=employeeList;
	}
	
	public String getColumnName(int col) {
		return columnNames[col];
	}
	
	@Override
	public int getColumnCount() {
		return columnNames.length;
	}

	@Override
	public int getRowCount() {
		return employeeList.size();
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
			switch(columnIndex) {
			case 0:
				return employeeList.get(rowIndex).getEmployeeId();
			case 1:
				return employeeList.get(rowIndex).getEmployeeName();
			case 2:
				return employeeList.get(rowIndex).getDesignation();
			case 3:
				return employeeList.get(rowIndex).getSalary();
			default:
				return null;
			}
	}

	

}